const data = require(".")

const axios = require("axios")

async function get_info(name){
    const {data} = await axios.get("http://api.tvmaze.com/search/shows?q=" + name)
    return data
}

async function get_show(input_id){
    const {data} = await axios.get("http://api.tvmaze.com/shows/" + input_id)
    return data
}

module.exports = {
    get_info, get_show
}